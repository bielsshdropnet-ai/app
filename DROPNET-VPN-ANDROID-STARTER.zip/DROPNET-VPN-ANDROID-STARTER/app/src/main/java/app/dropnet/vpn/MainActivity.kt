package app.dropnet.vpn

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("dropnet_profiles", MODE_PRIVATE) }
    private lateinit var host: EditText
    private lateinit var port: EditText
    private lateinit var username: EditText
    private lateinit var password: EditText
    private lateinit var sni: EditText
    private lateinit var status: TextView
    private lateinit var profiles: LinearLayout
    private val blue = Color.rgb(0, 160, 220)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 18, 35)
        window.navigationBarColor = Color.rgb(8, 18, 35)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(8, 18, 35))
        }
        page.addView(label("DROPNET VPN", 27, Color.WHITE))
        page.addView(label("GERENCIADOR DE PERFIS", 12, blue))
        page.addView(label("Cadastre configurações de servidores autorizados.", 14, Color.LTGRAY))

        host = field("Host ou IP do servidor")
        port = field("Porta (ex.: 22 ou 443)", "22")
        username = field("Login SSH")
        password = field("Senha SSH")
        password.inputType = 129
        sni = field("SNI (opcional)")
        listOf(host, port, username, password, sni).forEach { page.addView(it) }

        page.addView(button("SALVAR PERFIL") { saveProfile() })
        page.addView(button("AUTORIZAR VPN DO ANDROID") { requestVpnPermission() })
        status = label("Status: configuração inicial. Nenhum túnel está conectado.", 14, Color.YELLOW)
        page.addView(status)
        page.addView(label("PERFIS SALVOS", 17, Color.WHITE))
        profiles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(profiles)

        val scroll = ScrollView(this)
        scroll.addView(page)
        setContentView(scroll)
        renderProfiles()
    }

    private fun label(text: String, size: Int, color: Int) = TextView(this).apply {
        this.text = text
        textSize = size.toFloat()
        setTextColor(color)
        setPadding(0, 8, 0, 8)
    }

    private fun field(hintText: String, value: String = "") = EditText(this).apply {
        hint = hintText
        setText(value)
        setTextColor(Color.WHITE)
        setHintTextColor(Color.LTGRAY)
        textSize = 15f
        setSingleLine(true)
        setPadding(14, 8, 14, 8)
        backgroundTintList = android.content.res.ColorStateList.valueOf(blue)
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = 8 }
    }

    private fun button(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        backgroundTintList = android.content.res.ColorStateList.valueOf(blue)
        setOnClickListener { action() }
    }

    private fun saveProfile() {
        val h = host.text.toString().trim()
        val p = port.text.toString().trim()
        if (h.isBlank() || p.toIntOrNull() !in 1..65535) {
            status.text = "Informe um host e uma porta válida."
            return
        }
        val arr = JSONArray(prefs.getString("items", "[]"))
        arr.put(JSONObject().apply {
            put("host", h); put("port", p.toInt())
            put("username", username.text.toString())
            put("password", password.text.toString())
            put("sni", sni.text.toString())
        })
        prefs.edit().putString("items", arr.toString()).apply()
        status.text = "Perfil salvo neste aparelho."
        password.setText("")
        renderProfiles()
    }

    private fun renderProfiles() {
        if (!::profiles.isInitialized) return
        profiles.removeAllViews()
        val arr = JSONArray(prefs.getString("items", "[]"))
        for (i in 0 until arr.length()) {
            val item = arr.getJSONObject(i)
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val info = TextView(this).apply {
                text = "${i + 1}. ${item.optString("host")}:${item.optInt("port")}  SNI: ${item.optString("sni", "-")}"
                setTextColor(Color.WHITE)
                textSize = 13f
            }
            row.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val del = Button(this).apply {
                text = "EXCLUIR"
                setOnClickListener {
                    val updated = JSONArray()
                    for (j in 0 until arr.length()) if (j != i) updated.put(arr.getJSONObject(j))
                    prefs.edit().putString("items", updated.toString()).apply()
                    renderProfiles()
                }
            }
            row.addView(del)
            profiles.addView(row)
        }
    }

    private fun requestVpnPermission() {
        val intent = VpnService.prepare(this)
        if (intent == null) {
            status.text = "Permissão VPN já concedida. Motor de túnel ainda precisa ser integrado."
        } else {
            startActivityForResult(intent, 700)
        }
    }

    @Deprecated("Activity result kept simple for the starter project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 700) {
            status.text = if (resultCode == RESULT_OK)
                "Permissão VPN concedida. Ainda não há túnel conectado."
            else "Permissão VPN não concedida."
        }
    }
}

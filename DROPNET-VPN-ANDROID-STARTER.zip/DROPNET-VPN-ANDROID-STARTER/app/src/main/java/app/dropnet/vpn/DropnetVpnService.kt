package app.dropnet.vpn

import android.net.VpnService

// Estrutura inicial. Não estabelece interface TUN nem encaminha tráfego ainda.
// O motor de túnel autorizado será integrado numa etapa posterior.
class DropnetVpnService : VpnService()
